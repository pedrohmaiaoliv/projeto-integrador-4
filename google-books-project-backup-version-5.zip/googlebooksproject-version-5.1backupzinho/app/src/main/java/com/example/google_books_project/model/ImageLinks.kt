package com.example.google_books_project.model

data class ImageLinks(
    val thumbnail: String? // URL da miniatura da capa do livro
)
