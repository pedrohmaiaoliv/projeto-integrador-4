package com.example.google_books_project

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.google_books_project.adapter.BookAdapter
import com.example.google_books_project.model.BookItem
import com.example.google_books_project.model.BooksResponse
import com.example.google_books_project.util.RetrofitInstance
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var genreSpinner: Spinner
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var recyclerViewBooks: RecyclerView
    private lateinit var bookAdapter: BookAdapter
    private lateinit var searchEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        genreSpinner = findViewById(R.id.genre_spinner)
        adapter = ArrayAdapter(this, R.layout.spinner_item, mutableListOf("Gêneros"))
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        genreSpinner.adapter = adapter

        genreSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position != 0) {
                    val selectedGenre = parent.getItemAtPosition(position).toString()
                    Toast.makeText(this@MainActivity, "Gênero selecionado: $selectedGenre", Toast.LENGTH_SHORT).show()
                    searchBooksByGenre(selectedGenre)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        fetchGenres()
        recyclerViewBooks = findViewById(R.id.recyclerViewBooks)
        recyclerViewBooks.layoutManager = GridLayoutManager(this, 3)

        bookAdapter = BookAdapter(emptyList(), this::saveFavoriteBook)
        recyclerViewBooks.adapter = bookAdapter

        searchEditText = findViewById(R.id.searchEditText)
        searchEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                val query = searchEditText.text.toString().trim()
                if (query.isNotEmpty()) {
                    searchBooks(query)
                }
                true
            } else {
                false
            }
        }

        setupNavigationMenu()
    }

    private fun setupNavigationMenu() {
        val favoritesButton = findViewById<ImageButton>(R.id.favoritos)
        val settingsButton = findViewById<ImageButton>(R.id.configuracoes)

        favoritesButton.setOnClickListener {
            startActivity(Intent(this, FavoritesActivity::class.java))
        }

        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun fetchGenres() {
        val apiKey = getString(R.string.google_books_api_key)

        RetrofitInstance.api.searchBooks("subject", apiKey).enqueue(object : Callback<BooksResponse> {
            override fun onResponse(call: Call<BooksResponse>, response: Response<BooksResponse>) {
                if (response.isSuccessful) {
                    val books = response.body()?.items ?: emptyList()
                    val genres = books
                        .flatMap { it.volumeInfo.categories ?: emptyList() }
                        .distinct()
                        .sorted()
                    updateGenreSpinner(genres)
                }
            }

            override fun onFailure(call: Call<BooksResponse>, t: Throwable) {
                Log.e("MainActivity", "Erro ao buscar gêneros: ${t.message}")
            }
        })
    }

    private fun updateGenreSpinner(genres: List<String>) {
        adapter.clear()
        adapter.add("Gêneros")
        adapter.addAll(genres)
        adapter.notifyDataSetChanged()
    }

    private fun searchBooks(query: String) {
        val apiKey = getString(R.string.google_books_api_key)
        RetrofitInstance.api.searchBooks(query, apiKey).enqueue(object : Callback<BooksResponse> {
            override fun onResponse(call: Call<BooksResponse>, response: Response<BooksResponse>) {
                if (response.isSuccessful) {
                    val books = response.body()?.items ?: emptyList()
                    updateRecyclerView(books)
                }
            }

            override fun onFailure(call: Call<BooksResponse>, t: Throwable) {
                Log.e("MainActivity", "Erro na requisição de busca: ${t.message}")
            }
        })
    }

    private fun searchBooksByGenre(genre: String) {
        val apiKey = getString(R.string.google_books_api_key)
        RetrofitInstance.api.searchBooks("subject:$genre", apiKey).enqueue(object : Callback<BooksResponse> {
            override fun onResponse(call: Call<BooksResponse>, response: Response<BooksResponse>) {
                if (response.isSuccessful) {
                    val books = response.body()?.items ?: emptyList()
                    updateRecyclerView(books)
                }
            }

            override fun onFailure(call: Call<BooksResponse>, t: Throwable) {
                Log.e("MainActivity", "Erro: ${t.message}")
            }
        })
    }

    private fun updateRecyclerView(books: List<BookItem>) {
        bookAdapter = BookAdapter(books, this::saveFavoriteBook)
        recyclerViewBooks.adapter = bookAdapter
        bookAdapter.notifyDataSetChanged()
    }

    private fun saveFavoriteBook(book: BookItem, isFavorite: Boolean) {
        val sharedPref = getSharedPreferences("favorites", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()
        val gson = Gson()
        val json = sharedPref.getString("favorite_books", "[]")
        val type = object : TypeToken<MutableList<BookItem>>() {}.type
        val favoriteBooks: MutableList<BookItem> = gson.fromJson(json, type)

        if (isFavorite) {
            // Add to favorites if it doesn't already exist
            if (!favoriteBooks.contains(book)) {
                favoriteBooks.add(book)
            }
        } else {
            // Remove from favorites
            favoriteBooks.remove(book)
        }

        editor.putString("favorite_books", gson.toJson(favoriteBooks))
        editor.apply()
    }
}
