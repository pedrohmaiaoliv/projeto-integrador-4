package com.example.google_books_project

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.google_books_project.adapter.BookAdapter
import com.example.google_books_project.model.BookItem
import com.example.google_books_project.model.BooksResponse
import com.example.google_books_project.util.RetrofitInstance
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var genreSpinner: Spinner
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var recyclerViewBooks: RecyclerView
    private lateinit var bookAdapter: BookAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Configurações de bordas
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Inicializa o Spinner
        genreSpinner = findViewById(R.id.genre_spinner)
        adapter = ArrayAdapter(this, R.layout.spinner_item, mutableListOf("Gêneros"))
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        genreSpinner.adapter = adapter
       // genreSpinner.setBackgroundResource(R.drawable.spinner_background)

        genreSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position != 0) {
                    val selectedGenre = parent.getItemAtPosition(position).toString()
                    Toast.makeText(this@MainActivity, "Gênero selecionado: $selectedGenre", Toast.LENGTH_SHORT).show()
                    searchBooksByGenre(selectedGenre)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Busca gêneros e configura o RecyclerView
        fetchGenres()
        recyclerViewBooks = findViewById(R.id.recyclerViewBooks)
        recyclerViewBooks.layoutManager = GridLayoutManager(this, 3)

        // Inicializa o adaptador vazio
        bookAdapter = BookAdapter(emptyList())
        recyclerViewBooks.adapter = bookAdapter
    }

    private fun fetchGenres() {
        val apiKey = getString(R.string.google_books_api_key)

        RetrofitInstance.api.searchBooks("subject", apiKey).enqueue(object : Callback<BooksResponse> {
            override fun onResponse(call: Call<BooksResponse>, response: Response<BooksResponse>) {
                if (response.isSuccessful) {
                    val books = response.body()?.items ?: emptyList()
                    val genres = books
                        .flatMap { it.volumeInfo.categories ?: emptyList() }
                        .distinct()
                        .sorted()

                    updateGenreSpinner(genres)
                }
            }

            override fun onFailure(call: Call<BooksResponse>, t: Throwable) {
                Log.e("MainActivity", "Erro ao buscar gêneros: ${t.message}")
            }
        })
    }

    private fun updateGenreSpinner(genres: List<String>) {
        adapter.clear()
        adapter.add("Gêneros")
        adapter.addAll(genres)
        adapter.notifyDataSetChanged()
    }

    private fun searchBooksByGenre(genre: String) {
        val apiKey = getString(R.string.google_books_api_key)
        RetrofitInstance.api.searchBooks("subject:$genre", apiKey).enqueue(object : Callback<BooksResponse> {
            override fun onResponse(call: Call<BooksResponse>, response: Response<BooksResponse>) {
                if (response.isSuccessful) {
                    val books = response.body()?.items ?: emptyList()
                    updateRecyclerView(books)
                }
            }

            override fun onFailure(call: Call<BooksResponse>, t: Throwable) {
                Log.e("MainActivity", "Erro: ${t.message}")
            }
        })
    }

    private fun updateRecyclerView(books: List<BookItem>) {
        // Log das URLs das imagens
        books.forEach { book ->
            val imageUrl = book.volumeInfo.imageLinks?.thumbnail
            Log.d("MainActivity", "Título: ${book.volumeInfo.title}, URL da imagem: $imageUrl")
        }

        // Atualiza o adapter com a lista de livros recebida
        bookAdapter = BookAdapter(books)
        recyclerViewBooks.adapter = bookAdapter
        bookAdapter.notifyDataSetChanged()
    }
}
