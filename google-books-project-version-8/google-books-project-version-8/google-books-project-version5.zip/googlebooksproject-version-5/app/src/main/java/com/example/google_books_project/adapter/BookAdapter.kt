package com.example.google_books_project.adapter

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.google_books_project.R
import com.example.google_books_project.model.BookItem
import com.squareup.picasso.Picasso
import kotlin.concurrent.thread
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class BookAdapter(private val books: List<BookItem>) : RecyclerView.Adapter<BookAdapter.BookViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_book, parent, false)
        return BookViewHolder(view)
    }

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        val book = books[position]
        holder.bind(book)
    }

    override fun getItemCount(): Int = books.size

    inner class BookViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val bookCover: ImageView = itemView.findViewById(R.id.bookCover)
        private val bookTitle: TextView = itemView.findViewById(R.id.bookTitle)

        fun bind(book: BookItem) {
            bookTitle.text = book.volumeInfo.title ?: "Título Indisponível"

            // Verifica e carrega a imagem do livro
            val imageUrl = book.volumeInfo.imageLinks?.thumbnail
            Log.d("BookAdapter", "URL da Imagem: $imageUrl")

            if (imageUrl != null) {
                Picasso.get().load(imageUrl).into(bookCover)
//                thread {
//                    val bitmap = loadImageFromURL(imageUrl)
//                    bookCover.post {
//                        if (bitmap != null) {
//                            bookCover.setImageBitmap(bitmap)
//                        } else {
//                            Log.e("BookAdapter", "Erro ao carregar a imagem para a URL: $imageUrl")
//                        }
//                    }
//                }
            } else {
                Log.w("BookAdapter", "URL da imagem é nula para o livro: ${book.volumeInfo.title}")
            }
        }

        private fun loadImageFromURL(url: String): Bitmap? {
            Log.d("BookAdapter", "Carregando imagem da URL: $url")
            return try {
                val imageURL = URL(url)
                val connection = imageURL.openConnection() as HttpURLConnection
                connection.doInput = true
                connection.connect()
                val input: InputStream = connection.inputStream
                BitmapFactory.decodeStream(input)
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
}
