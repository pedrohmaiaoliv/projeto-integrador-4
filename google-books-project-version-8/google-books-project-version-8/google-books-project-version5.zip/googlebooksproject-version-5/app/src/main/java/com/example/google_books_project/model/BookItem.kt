package com.example.google_books_project.model

data class BookItem(
    val id: String,
    val volumeInfo: VolumeInfo
)
